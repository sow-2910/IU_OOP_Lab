package question3b;

public interface Resizable {
    public double resize(int percent);
}
