package question3b;

public interface GeometricObject {
    public double getPerimeter();

    public double getArea();
}
