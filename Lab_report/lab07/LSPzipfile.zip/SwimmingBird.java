public class SwimmingBird {
    public void swim(){
        System.out.println("I am swimming");
    }
}
