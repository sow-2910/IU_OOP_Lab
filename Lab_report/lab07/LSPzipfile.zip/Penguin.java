public class Penguin extends SwimmingBird {
    @Override
    public void swim(){
        System.out.println("I am a penguin and I am swimming");
    }
}
