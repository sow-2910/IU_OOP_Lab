public class FlyingBird {
    
}
